package com.example.cbtvnow;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.VideoView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.google.android.datatransport.backend.cct.BuildConfig;

public class MainActivity extends AppCompatActivity {
    private VideoView splashVideo;
    private WebView webView;
    private ImageView share;
    private ImageView cast;

    private final Handler mHideHandler = new Handler();
    private final Runnable mHidePart2Runnable = new Runnable() {
        @Override
        public void run() {
            hideButtons();
        }
    };

    static {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
     //   EdgeToEdge.enable(this);
        splashVideo = findViewById(R.id.splash_video1);
        webView = findViewById(R.id.liveWeb1);
        share = findViewById(R.id.share1);
        cast = findViewById(R.id.cast1);

        // Hide the status bar
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN);
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        // Initially hide the WebView
        webView.setVisibility(View.GONE);

        // Set up the video view
        Uri videoUri = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.initialvideo);
        splashVideo.setVideoURI(videoUri);


        webView.getSettings().setJavaScriptEnabled(true);
       // webView.setWebChromeClient(new MyChrome());
        webView.getSettings().getDisplayZoomControls();
        webView.getSettings().getUseWideViewPort();
        webView.setWebViewClient(new WebViewClient());


        // Thread to manage the main screen flow
        splashVideo.setOnCompletionListener(mediaPlayer -> {
            splashVideo.setVisibility(View.GONE);
            webView.setVisibility(View.VISIBLE);
            webView.loadUrl("https://cbtvnow.com:5866/hls/livest2024.m3u8");

            // Show share and cast buttons when WebView is shown
            share.setVisibility(View.VISIBLE);
            cast.setVisibility(View.VISIBLE);
        });
        splashVideo.start();

        // Set touch listeners for share and cast buttons
        setButtonTouchEffects(share);
        setButtonTouchEffects(cast);

        // Set click listener for share button
        share.setOnClickListener(v -> shareContent());

        // Hide share and cast buttons after 4 seconds of no interaction
        webView.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                showButtons(); // Show buttons on touch
                delayedHide(4000); // Hide after 4 seconds of no interaction
            }
            return false;
        });
    }

    private class MyChrome extends WebChromeClient
    {
        View fullscreen = null;

        @Override
        public void onHideCustomView()
        {
            fullscreen.setVisibility(View.GONE);
            webView.setVisibility(View.VISIBLE);
        }
        @Override
        public void onShowCustomView(View view, CustomViewCallback callback)
        {
            webView.setVisibility(View.GONE);

            if(fullscreen != null)
            {
                ((FrameLayout)getWindow().getDecorView()).removeView(fullscreen);
            }

            fullscreen = view;
            ((FrameLayout)getWindow().getDecorView()).addView(fullscreen, new FrameLayout.LayoutParams(-1, -1));
            fullscreen.setVisibility(View.VISIBLE);
        }
    }


    private void setButtonTouchEffects(ImageView button) {
        button.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                // Apply a scale down effect when button is pressed
                v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(100).start();
            }
            else if (event.getAction() == MotionEvent.ACTION_UP || event.getAction() == MotionEvent.ACTION_CANCEL) {
                // Restore original scale when button is released
                v.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
            }
            return false;
        });
    }

    private void shareContent() {
        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_TEXT,
                "Hey check out my app at: https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID);
        sendIntent.setType("text/plain");
        startActivity(sendIntent);
    }

    private void delayedHide(int delayMillis) {
        mHideHandler.removeCallbacks(mHidePart2Runnable);
        mHideHandler.postDelayed(mHidePart2Runnable, delayMillis);
    }

    private void hideButtons() {
        share.setVisibility(View.GONE);
        cast.setVisibility(View.GONE);
    }

    private void showButtons() {
        share.setVisibility(View.VISIBLE);
        cast.setVisibility(View.VISIBLE);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }
}

