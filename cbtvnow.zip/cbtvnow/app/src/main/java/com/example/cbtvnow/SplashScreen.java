package com.example.cbtvnow;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.VideoView;
import android.content.res.Configuration;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.google.android.datatransport.backend.cct.BuildConfig;
import com.google.android.gms.cast.framework.CastButtonFactory;
import com.google.android.gms.cast.framework.CastContext;
import com.google.android.gms.cast.framework.CastSession;
import com.google.android.gms.cast.framework.SessionManagerListener;

public class SplashScreen extends AppCompatActivity {
    private VideoView videoView;
    private Uri initialVideoUri;
    private String liveStreamUrl = "https://cbtvnow.com:5866/hls/livest2024.m3u8";
    private boolean isInitialVideoPlaying = true;


    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        videoView = findViewById(R.id.video_view);

        // Set initial video URI from raw resource (assuming it's placed in res/raw folder)
        initialVideoUri = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.initialvideo);

        // Play initial video
        playInitialVideo();
    }

    private void playInitialVideo() {
        videoView.setVideoURI(initialVideoUri);
        videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                // Start playback
                videoView.start();
            }
        });

        // Listen for video completion
        videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                // Switch to live stream
                playLiveStream();
            }
        });
    }

    private void playLiveStream() {
        videoView.setVideoURI(Uri.parse(liveStreamUrl));
        videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                // Start playback of live stream
                videoView.start();
            }
        });

        // Show controls for live stream
        videoView.setMediaController(new android.widget.MediaController(this));
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        // Handle orientation changes here if needed
    }
}